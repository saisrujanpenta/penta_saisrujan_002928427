/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.time.LocalDateTime;
import java.util.Date;


public class VitalSigns {

    LocalDateTime DateandTimeofEntry;

    public LocalDateTime getDateandTimeofEntry() {
        return DateandTimeofEntry;
    }

    public void setDateandTimeofEntry(LocalDateTime DateandTimeofEntry) {
        this.DateandTimeofEntry = DateandTimeofEntry;
    }

    public Date getDateofBirth() {
        return DateofBirth;
    }

    public void setDateofBirth(Date DateofBirth) {
        this.DateofBirth = DateofBirth;
    }
    Date DateofBirth;
    
    int saturation;

    public int getSaturation() {
        return saturation;
    }

    public void setSaturation(int saturation) {
        this.saturation = saturation;
    }
    
    double temperature;

    public double getTemperature() {
        return temperature;
    }

    public void setTemperature(double temperature) {
        this.temperature = temperature;
    }
    
}
