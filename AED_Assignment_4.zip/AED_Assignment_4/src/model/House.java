/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author saisr
 */
public class House {
    
    String House;

    public String getHouse() {
        return House;
    }

    public void setHouse(String House) {
        this.House = House;
    }
    
    
}
